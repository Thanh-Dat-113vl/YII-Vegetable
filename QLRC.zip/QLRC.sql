-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.17-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for QLRC
CREATE DATABASE IF NOT EXISTS `QLRC` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `QLRC`;

-- Dumping structure for table QLRC.banner
CREATE TABLE IF NOT EXISTS `banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.banner: ~0 rows (approximately)

-- Dumping structure for table QLRC.category
CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `fk_category_user` (`created_by`),
  CONSTRAINT `fk_category_user` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.category: ~3 rows (approximately)
INSERT INTO `category` (`id`, `name`, `slug`, `created_at`, `updated_at`, `status`, `created_by`, `image`) VALUES
	(1, 'Rau', 'Rau', '2025-09-12 00:54:37', '2025-10-02 03:45:28', 1, 4, ''),
	(2, 'Củ', 'Củ', '2025-09-12 00:55:58', '2025-09-12 00:55:58', 1, 4, ''),
	(4, 'Mì, miếng, cháo, phở', 'Mì-miếng-cháo-phở', '2025-09-12 03:38:24', '2025-11-07 14:15:59', 1, 4, ''),
	(8, 'Bột, gạo, đồ khô', 'bot-gao-do-kho', '2025-11-07 14:29:14', '2025-11-07 14:29:14', 1, 4, 'noimage.png'),
	(9, 'Nấm', 'nấm', '2025-11-07 14:32:46', '2025-11-07 14:32:46', 1, 4, 'noimage.png'),
	(10, 'Trái Cây', 'trái-cây', '2025-11-07 14:32:59', '2025-11-07 14:32:59', 1, 4, 'noimage.png');

-- Dumping structure for table QLRC.migration
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.migration: ~4 rows (approximately)
INSERT INTO `migration` (`version`, `apply_time`) VALUES
	('m000000_000000_base', 1755912293),
	('m240000_000001_add_order_code_to_orders', 1761963973),
	('m250823_012519_create_user_table', 1755912328),
	('m250823_040331_create_banner_table', 1755921860),
	('m250823_055729_create_user_table', 1755928715);

-- Dumping structure for table QLRC.orders
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_code` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','confirmed','shipping','completed','cancelled') NOT NULL DEFAULT 'pending',
  `payment_method` varchar(50) DEFAULT NULL,
  `shipping_address` text,
  `store_name` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `phone` varchar(11) NOT NULL,
  `delivery_type` varchar(225) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_code` (`order_code`),
  UNIQUE KEY `idx-orders-order_code` (`order_code`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.orders: ~12 rows (approximately)
INSERT INTO `orders` (`id`, `order_code`, `user_id`, `total_price`, `status`, `payment_method`, `shipping_address`, `store_name`, `created_at`, `updated_at`, `phone`, `delivery_type`) VALUES
	(1, 'ORD1762245880', 30, 516000.00, 'pending', NULL, NULL, 'BHX Thủ Đức (Ngã 4 Bình Thái)', '2025-11-04 08:44:47', '2025-11-04 08:45:26', '0704971299', 'store'),
	(6, 'ORD1762246623', 30, 1374500.00, 'pending', NULL, '', NULL, '2025-11-04 08:57:11', '2025-11-04 08:57:22', '0704971299', 'delivery'),
	(7, 'ORD1762246944', 30, 55000.00, 'pending', NULL, '', NULL, '2025-11-04 09:02:28', '2025-11-04 09:02:30', '0704971299', 'delivery'),
	(8, 'ORD1762304652', 30, 24500.00, 'pending', NULL, '', NULL, '2025-11-05 01:05:23', '2025-11-05 01:05:24', '0704971299', 'delivery'),
	(9, 'ORD1762304741', 30, 34000.00, 'pending', NULL, '', NULL, '2025-11-05 01:05:51', '2025-11-05 01:05:51', '0704971299', 'delivery'),
	(10, 'ORD1762309074', 30, 7650000.00, 'pending', NULL, NULL, 'BHX Quận 9 (Đỗ Xuân Hợp)', '2025-11-05 02:18:41', '2025-11-05 02:18:42', '0704971299', 'store'),
	(11, 'ORD1762409431', 30, 500000.00, 'pending', NULL, NULL, 'BHX Thủ Đức (Ngã 4 Bình Thái)', '2025-11-06 06:10:37', '2025-11-06 06:10:37', '0704971299', 'store'),
	(12, 'ORD1762411272', 30, 1341000.00, 'pending', NULL, 'vĩnh Long', NULL, '2025-11-06 06:41:18', '2025-11-06 06:41:18', '0704971299', 'delivery'),
	(13, 'ORD1762412015', 30, 555000.00, 'pending', 'bank', '', NULL, '2025-11-06 06:53:49', '2025-11-06 06:53:52', '0704971299', 'delivery'),
	(14, 'ORD1762418892', 30, 6504500.00, 'pending', 'cod', 'tân lập ', NULL, '2025-11-06 08:48:31', '2025-11-06 08:48:45', '0704971299', 'delivery'),
	(15, 'ORD1762419546', 30, 1341000.00, 'pending', 'cod', 'tân lập ', NULL, '2025-11-06 08:59:14', '2025-11-06 08:59:20', '0704971299', 'delivery'),
	(16, 'ORD1762419671', 30, 991000.00, 'pending', 'cod', 'ok', NULL, '2025-11-06 09:01:21', '2025-11-06 09:01:21', '0704971299', 'delivery');

-- Dumping structure for table QLRC.order_item
CREATE TABLE IF NOT EXISTS `order_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_order_item_orders` (`order_id`),
  KEY `FK_order_item_product` (`product_id`),
  CONSTRAINT `FK_order_item_orders` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_order_item_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.order_item: ~20 rows (approximately)
INSERT INTO `order_item` (`id`, `order_id`, `product_id`, `name`, `quantity`, `price`) VALUES
	(15, 1, 5, '', 1, 476000.00),
	(16, 1, 1, '', 1, 40000.00),
	(17, 6, 3, 'Window12', 1, 500000.00),
	(18, 6, 6, 'Mèo', 1, 850000.00),
	(19, 6, 8, 'mỳ Koreno', 1, 9500.00),
	(20, 7, 1, 'Window CTD', 1, 40000.00),
	(21, 8, 8, 'mỳ Koreno', 1, 9500.00),
	(22, 6, 8, 'mỳ Koreno', 2, 9500.00),
	(23, 9, 6, 'Mèo', 9, 850000.00),
	(24, 1, 3, 'Window12', 1, 500000.00),
	(25, 6, 6, 'Mèo', 1, 850000.00),
	(26, 8, 5, 'Rắn', 1, 476000.00),
	(27, 13, 3, 'Window12', 1, 500000.00),
	(28, 13, 1, 'Window CTD', 1, 40000.00),
	(29, 14, 7, 'Capybara', 1, 6480000.00),
	(30, 14, 8, 'mỳ Koreno', 1, 9500.00),
	(31, 15, 5, 'Rắn', 1, 476000.00),
	(32, 15, 6, 'Mèo', 1, 850000.00),
	(33, 16, 5, 'Rắn', 1, 476000.00),
	(34, 16, 3, 'Window12', 1, 500000.00);

-- Dumping structure for table QLRC.product
CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `unit` varchar(50) NOT NULL DEFAULT 'cái',
  `discount` int(11) DEFAULT '0',
  `description` text,
  `category_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `stock` int(11) DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT '0.0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `fk_product_created_by` (`created_by`),
  KEY `fk_product_category` (`category_id`),
  CONSTRAINT `fk_product_category` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_product_created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.product: ~8 rows (approximately)
INSERT INTO `product` (`id`, `created_by`, `updated_by`, `name`, `slug`, `price`, `unit`, `discount`, `description`, `category_id`, `image`, `stock`, `status`, `created_at`, `updated_at`, `rating`) VALUES
	(1, 4, 4, 'Rau muống hạt 400g', 'rau-mu-ng-h-t-400g', 16900.00, 'cái', 0, 'Rau muống hạt là một trong những loại rau xanh phổ biến trong bữa ăn hàng ngày của người Việt. Loại rau này được trồng từ hạt giống thay vì trồng từ thân như rau muống nước. Chính vì thế, rau muống hạt thường có cọng to, giòn và ngắn hơn, lá dày và đậm màu, vị đậm đà và bùi hơn so với rau muống nước. Rau muống hạt thích hợp trồng trong điều kiện khí hậu nhiệt đới và có thời gian thu hoạch nhanh, dễ chăm sóc. Đây là loại rau quen thuộc trong các món ăn dân dã như luộc, xào tỏi, nấu canh hoặc làm gỏi.', 1, 'product_1762499259.jpg', 1000, 1, '2025-10-01 07:43:02', '2025-11-07 14:07:43', 0.0),
	(2, 4, 4, 'Rau mồng tơi 400gr', 'rau-m-ng-t-i-400gr', 16900.00, 'cái', 70, 'Rau mồng tơi là một loại rau quen thuộc trong bữa ăn của người Việt Nam, đặc biệt phổ biến trong những ngày hè nhờ tính mát và dễ ăn. Với tên khoa học là Basella alba, mồng tơi thuộc họ mồng tơi (Basellaceae), có thân leo, lá màu xanh mướt, mềm và bóng. Rau mồng tơi không chỉ dễ trồng mà còn có hàm lượng dinh dưỡng cao, rất tốt cho hệ tiêu hoá, giúp thanh nhiệt và giải độc hiệu quả.', 1, 'product_1762499430.jpg', 100, 1, '2025-10-03 02:17:41', '2025-11-07 14:10:30', 0.0),
	(3, 4, 4, 'Cải bẹ dún 400g', 'c-i-b-d-n-400g', 16900.00, 'cái', 47, '', 1, 'product_1762499527.jpg', 500, 1, '2025-10-03 02:48:54', '2025-11-07 14:12:17', 0.0),
	(5, 4, 4, 'Bí đỏ hồ lô trái từ 750g - 1.4kg (1 trái)', 'b-h-l-tr-i-t-750g-1-4kg-1-tr-i-', 25000.00, 'kg', 36, 'Bí đỏ hồ lô trái từ 750g - 1.4kg (1 trái)', 2, 'product_1762499604.jpg', 1000, 1, '2025-10-04 04:25:19', '2025-11-07 14:13:24', 0.0),
	(6, 4, 4, 'Khoai tây củ từ 130g trở lên', 'khoai-t-y-c-t-130g-tr-l-n', 15000.00, 'kg', 0, 'Khoai tây thuộc họ cà, là một loại củ đa năng có hàm lượng chất dinh dưỡng cao, vì vậy nhiều hộ gia đình tại Việt Nam đã lựa chọn khoai tây như một món ăn chính trong các bữa ăn hàng ngày. Sở hữu nguồn vitamin và khoáng chất phong phú, khoai tây mang lại nhiều lợi ích cho sức khỏe như kháng viêm, giảm đau, tăng cường hệ miễn dịch, kích thích tiêu hóa,...', 2, 'product_1762499646.jpg', 100, 1, '2025-10-04 12:46:43', '2025-11-07 14:14:06', 0.0),
	(7, 4, 4, 'Cà chua bi 300g', 'c-chua-bi-300g', 19000.00, 'kg', 0, 'Ưu điểm khi mua cà chua bi tại Bách hoá XANH\r\nCà chua bi tươi ngon, thuộc loại cà chua có trái nhỏ nhưng căng, tròn và ngọt. Cà chua không bị hư, thối hay dập.\r\nCà chua bi được trồng tại Lâm Đồng, bảo đảm nguồn gốc xuất xứ rõ ràng.\r\nĐặt giao hàng nhanh', 2, 'product_1762499695.jpg', 1500, 1, '2025-10-04 12:49:30', '2025-11-07 14:14:55', 0.0),
	(8, 4, 30, 'mỳ Koreno', 'm-koreno', 9500.00, 'ly 65g', 0, 'Mì ăn liền dạng ly tiện lợi thơm ngon, sản xuất theo công nghệ Hàn Quốc, chính hãng mì Koreno được nhiều người yêu thích. Mì lẩu Thái Koreno hương vị chua cay ly 65g với sợi mì dai ngon, hương vị chuẩn Hàn hấp dẫn cùng 5 loại topping phong phú và dinh dưỡng cho gia đình bạn bữa ngon chất lượng', 4, 'product_1759557372.jpg', 496, 1, '2025-10-04 12:56:12', '2025-11-05 01:05:50', 0.0),
	(9, 4, 4, 'Dưa hấu', 'd-a-h-u', 39000.00, '3kg', 27, 'Dưa hấu đỏ trái 2.5 - 2.7kg (1 trái)', 10, 'product_1759557620.jpg', 0, 1, '2025-10-04 13:00:20', '2025-11-07 14:34:24', 0.0),
	(10, 4, NULL, 'Bí đỏ tròn (1-2 miếng/kg)', 'b-tr-n-1-2-mi-ng-kg-', 12500.00, '500g', 30, 'Ưu điểm khi mua bí đỏ \r\nBí đỏ chất lượng, ngon và béo ngậy cực kỳ hấp dẫn.\r\nBí được đảm bảo khối lượng và nguồn gốc xuất xứ.\r\nĐặt giao hàng nhanh.', 2, 'product_1762500657.jpg', 100, 1, '2025-11-07 14:30:57', '2025-11-07 14:30:57', 0.0),
	(11, 4, NULL, 'Dưa leo trái từ 100g trở lên', 'd-a-leo-tr-i-t-100g-tr-l-n', 17500.00, '500g', 23, 'Ưu điểm khi mua dưa leo\r\nDưa leo tươi, ngon, căng, mập mạp. Dưa leo giòn, ngọt cực kỳ ngon và chất lượng.\r\nDưa leo đảm bảo nguồn gốc xuất xứ rõ ràng.\r\nĐặt giao hàng nhanh\r\n\r\nGiá trị dinh dưỡng của dưa leo\r\nTrong dưa leo chứa nhiều nước, các vitamin C, vitamin K, … cùng những khoáng chất như magie, mangan, kali,...tốt cho sức khỏe.\r\nTrong 100g dưa leo có khoảng 15 Kcal.', 2, 'product_1762500738.jpg', 1500, 1, '2025-11-07 14:32:18', '2025-11-07 14:32:18', 0.0),
	(12, 4, NULL, 'Nấm kim châm Thái Lan 150g', 'n-m-kim-ch-m-th-i-lan-150g', 11000.00, 'gói', 0, 'Nấm kim châm tươi ngon, chất lượng, sợi nấm nhỏ, dài nhỏ màu trắng. Nấm dai ngon, giòn và khá ngọt. Nấm được đóng gói cẩn thận, tiện lợi.\r\n\r\nNấm được đảm bảo nguồn gốc xuất xứ rõ ràng tại Thái Lan, đóng gói 150g, không bị dập\r\n\r\nHàng đảm bảo tươi ngon, không dập \r\n\r\nĐảm bảo nguồn gốc xuất xứ, số lượng, khối lượng \r\n\r\nĐặt giao hàng nhanh', 9, 'product_1762500841.jpg', 1500, 1, '2025-11-07 14:34:01', '2025-11-07 14:34:01', 0.0),
	(13, 4, NULL, 'Cam sành vắt nước (trái từ 130g trở lên)', 'cam-s-nh-v-t-n-c-tr-i-t-130g-tr-l-n-', 3500.00, '500g', 0, 'Số lượng trái	\r\n6-8 trái/kg\r\nHướng dẫn sử dụng	\r\nCó thể ăn ngay hoặc nước ép\r\nHướng dẫn bảo quản	\r\nNơi khô ráo, thoáng mát hoặc trong ngăn mát tủ lạnh', 10, 'product_1762500916.jpg', 500, 1, '2025-11-07 14:35:16', '2025-11-07 14:35:16', 0.0);

-- Dumping structure for table QLRC.review
CREATE TABLE IF NOT EXISTS `review` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `comment` text,
  `created_at` datetime DEFAULT NULL,
  `review_name` varchar(255) NOT NULL,
  `review_phone` varchar(20) NOT NULL,
  `status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `review_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `review_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.review: ~0 rows (approximately)

-- Dumping structure for table QLRC.user
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `auth_key` varchar(32) NOT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT '2',
  `phone` varchar(20) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `verification_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.user: ~20 rows (approximately)
INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `role`, `phone`, `status`, `created_at`, `updated_at`, `verification_token`) VALUES
	(4, 'admin', '05sKvh0FgXfpab3e6AQidglLR_EDTpor', '$2y$13$XOenABYrSyFVGwrNxhUfruXWx1wIwwpBCBgoqTEM1GEXDPbm/nI3i', NULL, 'caothanh113vl1@gmail.com', '0', NULL, 10, '2025-08-27 09:49:01', '2025-09-26 09:50:24', 'HpTXE9amuFfuEAMKYTVpEXv4ZGH_k1oX_1756288141'),
	(6, 'dat', 'OyVUBZfxcQVNlo2akZFRW1RE8ysloCwN', '$2y$13$XyVFUqT3I6hqGHw/RR32NuLCYz6OYBVKTODT1NVO0BmoszO.SZI.y', NULL, 'caothanhdat113vl@gmail.com', '2', NULL, 10, '2025-09-17 08:05:25', '2025-09-22 07:26:17', NULL),
	(7, 'dat1', 'R6bPctojjAlsb8qiPqsFlXQXTdtiW2yA', '$2y$13$BjTz9lKRwHNgR6epT5c8SOt27gpvbsrfjpNA.qdoJv3mRLiYkfOEC', NULL, 'caothanh113vl@gmail.com', '1', NULL, 10, '2025-09-17 08:06:05', '2025-09-26 09:45:32', NULL),
	(8, 'test', '3IiHNkrgbPGBDMZOaJa2Jco4mjdiDNJo', '$2y$13$GIJ6zQVV1xizuXGxXuOgBuJzauj9KAAE2SFYvmUU1wdHfXePxeK5O', NULL, 'test@gmail.com', '0', NULL, 10, '2025-09-17 08:45:38', '2025-09-17 08:45:38', NULL),
	(9, '3', 'l_yWJNdIrnwEhrbVt9oUONHRH_eD15LY', '$2y$13$KE3GNjtISdiS0ebYNvWKEerpVmZzdGz1I1ZFFj5wtwXy1Bne3DfQ6', NULL, 'test1@gmail.com', '0', NULL, 10, '2025-09-20 04:24:11', '2025-09-20 04:24:11', NULL),
	(10, '1', 'CSa5gCkgijIoP-H5dBmXk1HQH3hBit1T', '$2y$13$jLrD38ZOizZEo8LiZhPZFez9JqEqJvyrDP69oHe/65mOvH8/cfuxS', NULL, 'test2@gmail.com', '0', NULL, 10, '2025-09-20 04:24:43', '2025-09-20 04:24:43', NULL),
	(11, '4', 'Ii6tFU4VdNT-DAXqwRc40CtrLRF6UFVm', '$2y$13$Ixed3TKNZlyFrT7hri6J4OyfjTg.hH9.qqq3kTUXi6o22XJmth1/C', NULL, 'test4@gmail.com', '0', NULL, 10, '2025-09-20 04:24:58', '2025-09-20 04:24:58', NULL),
	(17, '5', 'l_yWJNdIrnwEhrbVt9oUONHRH_eD15LY', '$2y$13$KE3GNjtISdiS0ebYNvWKEerpVmZzdGz1I1ZFFj5wtwXy1Bne3DfQ6', NULL, 'test5@gmail.com', '0', NULL, 10, '2025-09-20 04:24:11', '2025-09-20 04:24:11', NULL),
	(18, '6', 'Ii6tFU4VdNT-DAXqwRc40CtrLRF6UFVm', '$2y$13$Ixed3TKNZlyFrT7hri6J4OyfjTg.hH9.qqq3kTUXi6o22XJmth1/C', NULL, 'test6@gmail.com', '0', NULL, 10, '2025-09-20 04:24:58', '2025-09-20 04:24:58', NULL),
	(19, '7', 'Ii6tFU4VdNT-DAXqwRc40CtrLRF6UFVm', '$2y$13$Ixed3TKNZlyFrT7hri6J4OyfjTg.hH9.qqq3kTUXi6o22XJmth1/C', NULL, 'test7@gmail.com', '0', NULL, 10, '2025-09-20 04:24:58', '2025-09-20 04:24:58', NULL),
	(20, '8', 'Ii6tFU4VdNT-DAXqwRc40CtrLRF6UFVm', '$2y$13$Ixed3TKNZlyFrT7hri6J4OyfjTg.hH9.qqq3kTUXi6o22XJmth1/C', NULL, 'test8@gmail.com', '0', NULL, 10, '2025-09-20 04:24:58', '2025-09-20 04:24:58', NULL),
	(21, 'testctd', 'CcsfO23IpPlfo2O8QtC4qn6LRrP5iSnc', '$2y$13$p23ZSvKDy6d2yv5r2ah2wuPrzTDMhsU2xDAHFK5pGg6x9oqhRbQzW', NULL, 'testctd@gmail.com', '2', NULL, 10, '2025-09-23 03:58:15', '2025-09-23 03:58:15', NULL),
	(22, 'dat113', 'oMYk9so7vL9WW-qewrnOBiKkuNsizdSE', '$2y$13$5Yi0F3HtXWYLLsJYczEIQ.nNnNqqVKRECfbiK.v3F5RSDa4hzlH7a', NULL, 'dat113@gmail.com', '2', NULL, 10, '2025-09-25 09:01:54', '2025-09-25 09:01:54', NULL),
	(23, 'dat1134', 'MV6DheIKYT2QDiMSuthczHHKfn7eRb14', '$2y$13$OxrUdLsobIouPGL5LkU4CejHqomck7LuXhuMUsgiqh9SpX/f3Y7US', NULL, 'dat1134@gmail.com', '2', '0159854464', 10, '2025-09-26 01:31:46', '2025-09-26 01:31:46', NULL),
	(24, 'dat11345', 'zajF9jvqyfXEA1ZU3JdUlKmELuGzGOex', '$2y$13$2ZTmi8MnHOipJI5OC9TItO/fBJ0T.ZWXwy3Z2Ji1TfmIlb.6mzNEe', NULL, 'dat11345@gmail.com', '2', '0159854461', 10, '2025-09-26 01:36:58', '2025-09-26 01:36:58', NULL),
	(25, 'dat12', 'A6U3-HQqRwL-OO76lyUmD-kCYgL_nlp8', '$2y$13$I9H6gY1PeWeK5xD59B0UT.EerPcK70GSPuU3wCPQZiVmWW0A8QE7e', NULL, 'dat12@gmail.com', '2', '015985', 10, '2025-09-26 02:16:15', '2025-09-26 02:16:15', NULL),
	(26, 'dat1234', 'AfWYFB9seWiYSkaURVKYdnH1DMS8PEub', '$2y$13$U9T9MwvDvGHkfw5FdNjXguzpOUkPZeHEsvfpDHsgoez4xo0F.94/K', NULL, 'dat1234@gmail.com', '2', '0704971254', 10, '2025-09-26 07:37:58', '2025-09-26 07:37:58', NULL),
	(27, 'dat12345', 'jG2f3XoKO50vjVp-ZFnRIYPEh3iMaoQE', '$2y$13$63iSFIdQQB/GjQkwN69U7eIZ/s2j1MceulGhvWlK673vu.sg.0Gme', NULL, 'dat12345@gmail.com', '2', '0704971255', 10, '2025-09-26 07:50:02', '2025-09-26 07:50:02', NULL),
	(28, 'dat112', 'BDu4olOLl4vovsY5DKh-AHUprIz5lqFb', '$2y$13$xjEKqrhaK26hUJ3z8hA56.bL3AUGaRppLn10a3hj9vX3shzsYneA6', NULL, 'dat112@gmail.com', '2', '0704971252', 10, '2025-09-26 07:51:24', '2025-09-26 07:51:24', NULL),
	(29, 'admin1', 'oszbBoBYpTWt2pbZ7NImV08jYSiSppBW', '$2y$13$cEPjwrHSsyLEwfHjY4BcxOP5cRtNM7cxSJj/SRkpUjmd287r7LRF6', 'bYMSznAKfMpZKxY0W3lUYSwoE97AH7dU_1761902003', 'admin1@gmail.com', '0', '0704971251', 10, '2025-10-24 05:38:48', '2025-10-31 09:13:23', NULL),
	(30, 'admin2', 'dvczFumHBBvQbI7h4mFYVtrIGztiJu8r', '$2y$13$5k8TuFR0GvxXjtWzg00LhOhvzfTdGPgMMxzuNrHMtFBhknyaR6drG', NULL, 'admin2@gmail.com', '0', '0704971299', 10, '2025-10-31 09:19:51', '2025-10-31 09:19:51', NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
