-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.17-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for QLRC
CREATE DATABASE IF NOT EXISTS `QLRC` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `QLRC`;

-- Dumping structure for table QLRC.banner
CREATE TABLE IF NOT EXISTS `banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.banner: ~0 rows (approximately)

-- Dumping structure for table QLRC.category
CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `fk_category_user` (`created_by`),
  CONSTRAINT `fk_category_user` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.category: ~5 rows (approximately)
INSERT INTO `category` (`id`, `name`, `slug`, `created_at`, `updated_at`, `status`, `created_by`) VALUES
	(1, 'Rau', 'Rau', '2025-09-12 00:54:37', '2025-10-02 03:45:28', 1, 4),
	(2, 'Củ', 'Củ', '2025-09-12 00:55:58', '2025-09-12 00:55:58', 1, 4),
	(4, 'Đạt Cao', 'Đạt-cao', '2025-09-12 03:38:24', '2025-09-12 03:38:24', 1, 4),
	(6, 'Rau muốn', 'rau-muốn', '2025-09-12 09:01:21', '2025-09-12 09:01:21', 1, 4),
	(7, 'bách hóa xanh', 'dasdsdasd', '2025-10-01 06:04:57', '2025-10-01 06:05:05', 1, 4);

-- Dumping structure for table QLRC.migration
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.migration: ~4 rows (approximately)
INSERT INTO `migration` (`version`, `apply_time`) VALUES
	('m000000_000000_base', 1755912293),
	('m250823_012519_create_user_table', 1755912328),
	('m250823_040331_create_banner_table', 1755921860),
	('m250823_055729_create_user_table', 1755928715);

-- Dumping structure for table QLRC.orders
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','confirmed','shipping','completed','cancelled') DEFAULT 'pending',
  `payment_method` varchar(50) DEFAULT NULL,
  `shipping_address` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.orders: ~0 rows (approximately)

-- Dumping structure for table QLRC.order_item
CREATE TABLE IF NOT EXISTS `order_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.order_item: ~0 rows (approximately)

-- Dumping structure for table QLRC.product
CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `unit` varchar(50) NOT NULL DEFAULT 'cái',
  `discount` int(11) DEFAULT '0',
  `description` text,
  `category_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `stock` int(11) DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT '0.0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `fk_product_created_by` (`created_by`),
  KEY `fk_product_category` (`category_id`),
  CONSTRAINT `fk_product_category` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_product_created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.product: ~8 rows (approximately)
INSERT INTO `product` (`id`, `created_by`, `updated_by`, `name`, `slug`, `price`, `unit`, `discount`, `description`, `category_id`, `image`, `stock`, `status`, `created_at`, `updated_at`, `rating`) VALUES
	(1, 4, 4, 'Window CTD', 'window-ctd', 50000.00, 'cái', 20, 'con dogs hehe oki123 CTD', 6, 'product_1759472693.jpg', 1234, 1, '2025-10-01 07:43:02', '2025-10-03 06:51:21', 0.0),
	(2, 4, NULL, 'Window1', 'window1', 500000.00, 'cái', 0, 'ok la', 4, 'product_1759457859.jpg', 100, 1, '2025-10-03 02:17:41', '2025-10-03 02:17:35', 0.0),
	(3, 4, NULL, 'Window12', 'window12', 500000.00, 'cái', 0, 'oki la', 2, 'product_1759459734.jpg', 500, 1, '2025-10-03 02:48:54', '2025-10-03 02:48:53', 0.0),
	(5, 4, NULL, 'Rắn', 'r-n', 952000.00, 'kg', 50, 'rắn ngon', 7, 'product_1759551916.jpg', 50000, 1, '2025-10-04 04:25:19', '2025-10-04 04:25:09', 0.0),
	(6, 4, NULL, 'Mèo', 'm-o', 1000000.00, 'kg', 15, 'Mèo ngon nha', 4, 'product_1759556798.jpg', 500, 1, '2025-10-04 12:46:43', '2025-10-04 12:46:43', 0.0),
	(7, 4, NULL, 'Capybara', 'capybara', 8000000.00, 'kg', 19, 'capybara ngon á', 1, 'product_1759556970.jpg', 100, 1, '2025-10-04 12:49:30', '2025-10-04 12:49:30', 0.0),
	(8, 4, NULL, 'mỳ Koreno', 'm-koreno', 9500.00, 'ly 65g', 0, 'Mì ăn liền dạng ly tiện lợi thơm ngon, sản xuất theo công nghệ Hàn Quốc, chính hãng mì Koreno được nhiều người yêu thích. Mì lẩu Thái Koreno hương vị chua cay ly 65g với sợi mì dai ngon, hương vị chuẩn Hàn hấp dẫn cùng 5 loại topping phong phú và dinh dưỡng cho gia đình bạn bữa ngon chất lượng', 4, 'product_1759557372.jpg', 500, 1, '2025-10-04 12:56:12', '2025-10-04 12:56:12', 0.0),
	(9, 4, NULL, 'Dưa hấu', 'd-a-h-u', 39000.00, '3kg', 27, 'Dưa hấu đỏ trái 2.5 - 2.7kg (1 trái)', 2, 'product_1759557620.jpg', 0, 1, '2025-10-04 13:00:20', '2025-10-04 13:00:20', 0.0);

-- Dumping structure for table QLRC.review
CREATE TABLE IF NOT EXISTS `review` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `comment` text,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `review_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `review_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.review: ~0 rows (approximately)

-- Dumping structure for table QLRC.user
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `auth_key` varchar(32) NOT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT '2',
  `phone` varchar(20) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `verification_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- Dumping data for table QLRC.user: ~19 rows (approximately)
INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `role`, `phone`, `status`, `created_at`, `updated_at`, `verification_token`) VALUES
	(4, 'admin', '05sKvh0FgXfpab3e6AQidglLR_EDTpor', '$2y$13$XOenABYrSyFVGwrNxhUfruXWx1wIwwpBCBgoqTEM1GEXDPbm/nI3i', NULL, 'caothanh113vl1@gmail.com', '0', NULL, 10, '2025-08-27 09:49:01', '2025-09-26 09:50:24', 'HpTXE9amuFfuEAMKYTVpEXv4ZGH_k1oX_1756288141'),
	(6, 'dat', 'OyVUBZfxcQVNlo2akZFRW1RE8ysloCwN', '$2y$13$XyVFUqT3I6hqGHw/RR32NuLCYz6OYBVKTODT1NVO0BmoszO.SZI.y', NULL, 'caothanhdat113vl@gmail.com', '2', NULL, 10, '2025-09-17 08:05:25', '2025-09-22 07:26:17', NULL),
	(7, 'dat1', 'R6bPctojjAlsb8qiPqsFlXQXTdtiW2yA', '$2y$13$BjTz9lKRwHNgR6epT5c8SOt27gpvbsrfjpNA.qdoJv3mRLiYkfOEC', NULL, 'caothanh113vl@gmail.com', '1', NULL, 10, '2025-09-17 08:06:05', '2025-09-26 09:45:32', NULL),
	(8, 'test', '3IiHNkrgbPGBDMZOaJa2Jco4mjdiDNJo', '$2y$13$GIJ6zQVV1xizuXGxXuOgBuJzauj9KAAE2SFYvmUU1wdHfXePxeK5O', NULL, 'test@gmail.com', '0', NULL, 10, '2025-09-17 08:45:38', '2025-09-17 08:45:38', NULL),
	(9, '3', 'l_yWJNdIrnwEhrbVt9oUONHRH_eD15LY', '$2y$13$KE3GNjtISdiS0ebYNvWKEerpVmZzdGz1I1ZFFj5wtwXy1Bne3DfQ6', NULL, 'test1@gmail.com', '0', NULL, 10, '2025-09-20 04:24:11', '2025-09-20 04:24:11', NULL),
	(10, '1', 'CSa5gCkgijIoP-H5dBmXk1HQH3hBit1T', '$2y$13$jLrD38ZOizZEo8LiZhPZFez9JqEqJvyrDP69oHe/65mOvH8/cfuxS', NULL, 'test2@gmail.com', '0', NULL, 10, '2025-09-20 04:24:43', '2025-09-20 04:24:43', NULL),
	(11, '4', 'Ii6tFU4VdNT-DAXqwRc40CtrLRF6UFVm', '$2y$13$Ixed3TKNZlyFrT7hri6J4OyfjTg.hH9.qqq3kTUXi6o22XJmth1/C', NULL, 'test4@gmail.com', '0', NULL, 10, '2025-09-20 04:24:58', '2025-09-20 04:24:58', NULL),
	(17, '5', 'l_yWJNdIrnwEhrbVt9oUONHRH_eD15LY', '$2y$13$KE3GNjtISdiS0ebYNvWKEerpVmZzdGz1I1ZFFj5wtwXy1Bne3DfQ6', NULL, 'test5@gmail.com', '0', NULL, 10, '2025-09-20 04:24:11', '2025-09-20 04:24:11', NULL),
	(18, '6', 'Ii6tFU4VdNT-DAXqwRc40CtrLRF6UFVm', '$2y$13$Ixed3TKNZlyFrT7hri6J4OyfjTg.hH9.qqq3kTUXi6o22XJmth1/C', NULL, 'test6@gmail.com', '0', NULL, 10, '2025-09-20 04:24:58', '2025-09-20 04:24:58', NULL),
	(19, '7', 'Ii6tFU4VdNT-DAXqwRc40CtrLRF6UFVm', '$2y$13$Ixed3TKNZlyFrT7hri6J4OyfjTg.hH9.qqq3kTUXi6o22XJmth1/C', NULL, 'test7@gmail.com', '0', NULL, 10, '2025-09-20 04:24:58', '2025-09-20 04:24:58', NULL),
	(20, '8', 'Ii6tFU4VdNT-DAXqwRc40CtrLRF6UFVm', '$2y$13$Ixed3TKNZlyFrT7hri6J4OyfjTg.hH9.qqq3kTUXi6o22XJmth1/C', NULL, 'test8@gmail.com', '0', NULL, 10, '2025-09-20 04:24:58', '2025-09-20 04:24:58', NULL),
	(21, 'testctd', 'CcsfO23IpPlfo2O8QtC4qn6LRrP5iSnc', '$2y$13$p23ZSvKDy6d2yv5r2ah2wuPrzTDMhsU2xDAHFK5pGg6x9oqhRbQzW', NULL, 'testctd@gmail.com', '2', NULL, 10, '2025-09-23 03:58:15', '2025-09-23 03:58:15', NULL),
	(22, 'dat113', 'oMYk9so7vL9WW-qewrnOBiKkuNsizdSE', '$2y$13$5Yi0F3HtXWYLLsJYczEIQ.nNnNqqVKRECfbiK.v3F5RSDa4hzlH7a', NULL, 'dat113@gmail.com', '2', NULL, 10, '2025-09-25 09:01:54', '2025-09-25 09:01:54', NULL),
	(23, 'dat1134', 'MV6DheIKYT2QDiMSuthczHHKfn7eRb14', '$2y$13$OxrUdLsobIouPGL5LkU4CejHqomck7LuXhuMUsgiqh9SpX/f3Y7US', NULL, 'dat1134@gmail.com', '2', '0159854464', 10, '2025-09-26 01:31:46', '2025-09-26 01:31:46', NULL),
	(24, 'dat11345', 'zajF9jvqyfXEA1ZU3JdUlKmELuGzGOex', '$2y$13$2ZTmi8MnHOipJI5OC9TItO/fBJ0T.ZWXwy3Z2Ji1TfmIlb.6mzNEe', NULL, 'dat11345@gmail.com', '2', '0159854461', 10, '2025-09-26 01:36:58', '2025-09-26 01:36:58', NULL),
	(25, 'dat12', 'A6U3-HQqRwL-OO76lyUmD-kCYgL_nlp8', '$2y$13$I9H6gY1PeWeK5xD59B0UT.EerPcK70GSPuU3wCPQZiVmWW0A8QE7e', NULL, 'dat12@gmail.com', '2', '015985', 10, '2025-09-26 02:16:15', '2025-09-26 02:16:15', NULL),
	(26, 'dat1234', 'AfWYFB9seWiYSkaURVKYdnH1DMS8PEub', '$2y$13$U9T9MwvDvGHkfw5FdNjXguzpOUkPZeHEsvfpDHsgoez4xo0F.94/K', NULL, 'dat1234@gmail.com', '2', '0704971254', 10, '2025-09-26 07:37:58', '2025-09-26 07:37:58', NULL),
	(27, 'dat12345', 'jG2f3XoKO50vjVp-ZFnRIYPEh3iMaoQE', '$2y$13$63iSFIdQQB/GjQkwN69U7eIZ/s2j1MceulGhvWlK673vu.sg.0Gme', NULL, 'dat12345@gmail.com', '2', '0704971255', 10, '2025-09-26 07:50:02', '2025-09-26 07:50:02', NULL),
	(28, 'dat112', 'BDu4olOLl4vovsY5DKh-AHUprIz5lqFb', '$2y$13$xjEKqrhaK26hUJ3z8hA56.bL3AUGaRppLn10a3hj9vX3shzsYneA6', NULL, 'dat112@gmail.com', '2', '0704971252', 10, '2025-09-26 07:51:24', '2025-09-26 07:51:24', NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
